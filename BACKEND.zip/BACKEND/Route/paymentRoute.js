import express from "express";
import paymentControllers from "../Controllers/paymentControllers.js";

const router = express.Router();

// IMPORTANT: Put specific routes BEFORE parameter routes
// Upload image route should come before the /:id routes
router.post("/upload-image", paymentControllers.upload.single("image"), paymentControllers.handlePaymentImageUpload);

// Get all payments
router.get("/", paymentControllers.getAllPayments);

// Create new payment
router.post("/", paymentControllers.createPayment);

// Routes with parameters should come AFTER specific routes
// Get payment by ID
router.get("/:id", paymentControllers.getPaymentById);

// Update payment
router.put("/:id", paymentControllers.updatePayment);

// Delete payment
router.delete("/:id", paymentControllers.deletePayment);

export default router;